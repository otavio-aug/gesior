local QRCodeWindow = nil
local changed = false
local qrcodeImage = nil

local baseSiteUrl = "http://158.69.175.192"
local apiUrl = baseSiteUrl.."/api/donate/pix/generatePayload.php"

local promotions = "2x acima de 30 pontos.\n3x acima de 50 pontos."

local windowSizeForPromotions = {
  width = 280,
  height = 350
}

function showPromotions()
  if not shop or not pixWindow then return end
  if (#promotions > 0) then
    pixWindow:setWidth(windowSizeForPromotions.width)
    pixWindow:setHeight(windowSizeForPromotions.height)
    local promotionsContainer = g_ui.createWidget("PromotionsContainer", pixWindow)
    local promotionsText = "Available promotions\n"..promotions
    promotionsContainer:setText(promotionsText)
  end
end

function showPixInformation()
  if not shop then return end
  if (not pixWindow) then
    createPixWindow()
  end
  hide()
  pixWindow:show()
  pixWindow:raise()
  pixWindow:focus()
  showPromotions()
end

function hidePixInformation()
  if not shop or not pixWindow then return end
  pixWindow:hide()
  show()
end

function destroyPixInformation()
  if not shop or not pixWindow then return end
  pixWindow:hide()
  pixWindow:destroy()
  pixWindow = nil
  show()
end

function destroyQRCodeWindow()
  if (not QRCodeWindow) then return end
  QRCodeWindow:hide()
  show()
  QRCodeWindow:destroy()
  QRCodeWindow = nil
end

function hideQRCodeWindow()
  if (not QRCodeWindow) then return end
  QRCodeWindow:hide()
  show()
end

function sanitizeValue(value)
  value = value:match("^[^.,]*") or ""
  local sanitized = value:gsub("%D", "")
  return tonumber(sanitized) or ""
end

function createQRCodeWindow()
  if QRCodeWindow then return end
  QRCodeWindow = g_ui.displayUI('QRCodeWindow')
  qrcodeImage = QRCodeWindow:getChildById("qrcode")
  changed = false
  updateFrame()
end

function removeAccents(str)
  local accentsMap = {
      ['�'] = 'a', ['�'] = 'a', ['�'] = 'a', ['�'] = 'a', ['�'] = 'a',
      ['�'] = 'e', ['�'] = 'e', ['�'] = 'e', ['�'] = 'e',
      ['�'] = 'i', ['�'] = 'i', ['�'] = 'i', ['�'] = 'i',
      ['�'] = 'o', ['�'] = 'o', ['�'] = 'o', ['�'] = 'o', ['�'] = 'o',
      ['�'] = 'u', ['�'] = 'u', ['�'] = 'u', ['�'] = 'u',
      ['�'] = 'c',
      ['�'] = 'A', ['�'] = 'A', ['�'] = 'A', ['�'] = 'A', ['�'] = 'A',
      ['�'] = 'E', ['�'] = 'E', ['�'] = 'E', ['�'] = 'E',
      ['�'] = 'I', ['�'] = 'I', ['�'] = 'I', ['�'] = 'I',
      ['�'] = 'O', ['�'] = 'O', ['�'] = 'O', ['�'] = 'O', ['�'] = 'O',
      ['�'] = 'U', ['�'] = 'U', ['�'] = 'U', ['�'] = 'U',
      ['�'] = 'C'
  }
  return (str:gsub("[%z\1-\127\194-\244][\128-\191]*", accentsMap))
end

function sendQRCodeWindow()
  if not pixWindow then return end

  local name = removeAccents(pixWindow:getChildById("name"):getText())
  local email = removeAccents(pixWindow:getChildById("email"):getText())
  local rawValue = pixWindow:getChildById("value"):getText()

  if (not name or not email or not rawValue) then hidePixInformation() return true end

  local value = sanitizeValue(rawValue)
  if (value == "") then hidePixInformation() return true end

  local paymentData = {
    value = value,
    email = email,
    name = name,
    playerName = "Taliban",
    -- playerName = g_game.getLocalPlayer():getName(),
  }

  hidePixInformation()
  createQRCodeWindow()
  generatePixPayload(paymentData)
end

function sendInvalidDataError()
  local infoBox = displayInfoBox(tr('Error'), "Invalid data.")
  infoBox:lock()
  infoBox:raise()
  infoBox:focus()
  shop:addChild(infoBox)
end
function generatePixPayload(paymentData)
  HTTP.postJSON(apiUrl, json.encode(paymentData),
  function(data, err)
    if err then
        destroyQRCodeWindow()
        return true
    end
    if (not data or not data["qr_code"]) then
        for k, v in pairs(data) do
          g_logger.info(k)
          g_logger.info(v)
        end
        sendInvalidDataError()
        destroyQRCodeWindow()
        return true
    end
    if (qrcodeImage) then
      qrcodeImage:setImageSourceBase64(data["qr_code"])
      changed = true
    end
  end)
end

local currentFrame = 1

local frames = {
  "frame_00_delay-0.04s",
  "frame_01_delay-0.04s",
  "frame_02_delay-0.04s",
  "frame_03_delay-0.04s",
  "frame_04_delay-0.04s",
  "frame_05_delay-0.04s",
  "frame_06_delay-0.04s",
  "frame_07_delay-0.04s",
  "frame_08_delay-0.04s",
  "frame_09_delay-0.04s",
  "frame_10_delay-0.04s",
  "frame_11_delay-0.04s",
  "frame_12_delay-0.04s",
  "frame_13_delay-0.04s",
  "frame_14_delay-0.04s",
  "frame_15_delay-0.04s",
  "frame_16_delay-0.04s",
  "frame_17_delay-0.04s",
  "frame_18_delay-0.04s",
  "frame_19_delay-0.04s",
  "frame_20_delay-0.04s",
  "frame_21_delay-0.04s",
  "frame_22_delay-0.04s",
  "frame_23_delay-0.04s",
  "frame_24_delay-0.04s",
  "frame_25_delay-0.04s",
  "frame_26_delay-0.04s",
  "frame_27_delay-0.04s",
  "frame_28_delay-0.04s",
  "frame_29_delay-0.04s",
  "frame_30_delay-0.04s",
  "frame_31_delay-0.04s",
  "frame_32_delay-0.04s",
  "frame_33_delay-0.04s",
  "frame_34_delay-0.04s",
  "frame_35_delay-0.04s",
  "frame_36_delay-0.04s",
  "frame_37_delay-0.04s",
  "frame_38_delay-0.04s",
  "frame_39_delay-0.04s",
  "frame_40_delay-0.04s",
  "frame_41_delay-0.04s",
  "frame_42_delay-0.04s",
  "frame_43_delay-0.04s",
  "frame_44_delay-0.04s",
  "frame_45_delay-0.04s",
  "frame_46_delay-0.04s",
  "frame_47_delay-0.04s",
  "frame_48_delay-0.04s",
  "frame_49_delay-0.04s",
  "frame_50_delay-0.04s",
  "frame_51_delay-0.04s",
  "frame_52_delay-0.04s",
  "frame_53_delay-0.04s",
  "frame_54_delay-0.04s",
  "frame_55_delay-0.04s",
  "frame_56_delay-0.04s",
  "frame_57_delay-0.04s",
  "frame_58_delay-0.04s",
  "frame_59_delay-0.04s",
  "frame_60_delay-0.04s",
  "frame_61_delay-0.04s",
  "frame_62_delay-0.04s"
}


function updateFrame()
  if qrcodeImage and not changed then
      qrcodeImage:setImageSource("/modules/game_shop/images/spin/" .. frames[currentFrame])
      currentFrame = currentFrame + 1
      if currentFrame > #frames then
          currentFrame = 1 
      end
      scheduleEvent(function() updateFrame() end, 40)
  end
end